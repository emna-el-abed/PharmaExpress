package com.example.emna.Entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import com.example.emna.Entity.Medicament;
@Getter
@Setter
@Entity
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    @Size(min = 3, max = 100)
    private String customerName;

    @NotNull
    @Size(min = 8, max = 8)
    private String customerPhone;

    @Column(nullable = false, updatable = false)
    private LocalDateTime orderDate;

    @ManyToOne
    @Size(min = 3, max = 50)
    private Medicament medicament;

    @NotNull
    private Double totalAmount;

    @NotNull
    @Size(min = 3, max = 50)
    private String status;

}
