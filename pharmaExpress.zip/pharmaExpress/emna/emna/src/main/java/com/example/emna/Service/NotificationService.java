package com.example.emna.Service;

import com.example.emna.Entity.Notification;
import com.example.emna.Repository.NotificationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class NotificationService {

    @Autowired
    private NotificationRepository notificationRepository;

    // Get all notifications
    public List<Notification> getAllNotifications() {
        return notificationRepository.findAll();
    }

    // Get notification by ID
    public Optional<Notification> getNotificationById(Long id) {
        return notificationRepository.findById(id);
    }

    // Create new notification
    public Notification createNotification(Notification notification) {
        return notificationRepository.save(notification);
    }

    // Update existing notification
    public Optional<Notification> updateNotification(Long id, Notification updatedNotification) {
        return notificationRepository.findById(id).map(notification -> {
            notification.setMessage(updatedNotification.getMessage());
            notification.setUserId(updatedNotification.getUserId());
            notification.setNotificationType(updatedNotification.getNotificationType());
            return notificationRepository.save(notification);
        });
    }

    // Delete notification
    public boolean deleteNotification(Long id) {
        if (notificationRepository.existsById(id)) {
            notificationRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
