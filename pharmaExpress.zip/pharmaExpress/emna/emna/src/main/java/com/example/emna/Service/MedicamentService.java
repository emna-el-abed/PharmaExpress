package com.example.emna.Service;

import com.example.emna.Entity.Medicament;
import com.example.emna.Repository.MedicamentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class MedicamentService {

    @Autowired
    private MedicamentRepository medicamentRepository;

    // Create a new medicament
    public Medicament createMedicament(Medicament medicament) {
        return medicamentRepository.save(medicament);
    }

    // Get all medicaments
    public List<Medicament> getAllMedicaments() {
        return medicamentRepository.findAll();
    }

    // Get a medicament by ID
    public Optional<Medicament> getMedicamentById(Long id) {
        return medicamentRepository.findById(id);
    }

    // Update a medicament
    public Medicament updateMedicament(Long id, Medicament medicament) {
        if (medicamentRepository.existsById(id)) {
            medicament.setId(id);
            return medicamentRepository.save(medicament);
        } else {
            return null;
        }
    }

    // Delete a medicament
    public void deleteMedicament(Long id) {
        medicamentRepository.deleteById(id);
    }
}
