package com.example.emna.Service;

import com.example.emna.Entity.Conversation;
import com.example.emna.Repository.ConversationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class ConversationService {

    @Autowired
    private ConversationRepository conversationRepository;

    public Optional<Conversation> findById(Long id) {
        return conversationRepository.findById(id);
    }

    public Conversation createConversation(Conversation conversation) {
        return conversationRepository.save(conversation);
    }
}
