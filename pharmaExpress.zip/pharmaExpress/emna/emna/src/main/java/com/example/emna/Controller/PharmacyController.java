package com.example.emna.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.emna.Service.PharmacyService;
import com.example.emna.Entity.Pharmacy;
import com.example.emna.Service.GpsLocationService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/pharmacies")
public class PharmacyController {

    private final PharmacyService pharmacyService;
    private final GpsLocationService gpsLocationService;

    @Autowired
    public PharmacyController(PharmacyService pharmacyService, GpsLocationService gpsLocationService) {
        this.pharmacyService = pharmacyService;
        this.gpsLocationService = gpsLocationService;
    }

    // Create or update pharmacy
    @PostMapping
    public ResponseEntity<Pharmacy> createOrUpdatePharmacy(@RequestBody Pharmacy pharmacy) {
        Pharmacy savedPharmacy = pharmacyService.savePharmacy(pharmacy);
        return new ResponseEntity<>(savedPharmacy, HttpStatus.CREATED);
    }

    // Get all pharmacies
    @GetMapping
    public ResponseEntity<List<Pharmacy>> getAllPharmacies() {
        List<Pharmacy> pharmacies = pharmacyService.getAllPharmacies();
        return new ResponseEntity<>(pharmacies, HttpStatus.OK);
    }

    // Get pharmacy by id
    @GetMapping("/{id}")
    public ResponseEntity<Pharmacy> getPharmacyById(@PathVariable Long id) {
        Optional<Pharmacy> pharmacy = pharmacyService.getPharmacyById(id);
        return pharmacy.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Delete pharmacy by id
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePharmacy(@PathVariable Long id) {
        pharmacyService.deletePharmacy(id);
        return ResponseEntity.noContent().build();
    }

    // Get pharmacies nearby the user based on GPS location
    @GetMapping("/nearby")
    public ResponseEntity<List<Pharmacy>> getNearbyPharmacies(
            @RequestParam double userLat,
            @RequestParam double userLon,
            @RequestParam(defaultValue = "5") double radius) {

        List<Pharmacy> pharmacies = pharmacyService.getAllPharmacies();
        List<Pharmacy> nearbyPharmacies = gpsLocationService.findNearbyPharmacies(userLat, userLon, pharmacies, radius);

        if (nearbyPharmacies.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);  // No nearby pharmacies
        } else {
            return ResponseEntity.ok(nearbyPharmacies);
        }
    }
}
