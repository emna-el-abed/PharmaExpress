package com.example.emna.Service;

import com.example.emna.Repository.UserRepository;
import com.example.emna.Entity.User;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    // Create or Update User
    public User saveUser(User user) {
        return userRepository.save(user);
    }

    // Get All Users
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    // Get User by CIN
    public Optional<User> getUserByCin(Long cin) {
        return userRepository.findByCin(cin);  // Use the custom method findByCin
    }

    // Delete User by CIN
    public void deleteUser(Long cin) {
        userRepository.deleteByCin(cin);  // Make sure to add deleteByCin in the repository if not already
    }
}
