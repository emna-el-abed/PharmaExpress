package com.example.emna.Service;

import com.example.emna.Entity.Pharmacy;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class GpsLocationService {

    public List<Pharmacy> findNearbyPharmacies(double userLat, double userLon, List<Pharmacy> pharmacies, double radius) {
        return pharmacies.stream()
                .filter(pharmacy -> calculateDistance(userLat, userLon, pharmacy.getLatitude(), pharmacy.getLongitude()) <= radius)
                .collect(Collectors.toList());
    }

    // Calculate distance between two geographical points (in km)
    private double calculateDistance(double lat1, double lon1, double lat2, double lon2) {
        final double EARTH_RADIUS = 6371.0; // Radius of the Earth in kilometers

        double latDistance = Math.toRadians(lat2 - lat1);
        double lonDistance = Math.toRadians(lon2 - lon1);
        double a = Math.sin(latDistance / 2) * Math.sin(latDistance / 2) +
                Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
                        Math.sin(lonDistance / 2) * Math.sin(lonDistance / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        double distance = EARTH_RADIUS * c;

        return distance; // distance in kilometers
    }
}
