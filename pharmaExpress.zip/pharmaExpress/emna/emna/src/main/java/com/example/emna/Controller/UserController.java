package com.example.emna.Controller;

import com.example.emna.Entity.User;
import com.example.emna.Service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/users")
public class UserController {

    @Autowired
    private UserService userService;

    // Show All Users
    @GetMapping
    public List<User> listUsers() {
        return userService.getAllUsers();
    }

    // Show a Specific User
    @GetMapping("/{cin}")
    public ResponseEntity<User> getUserByCin(@PathVariable("cin") Long cin) {
        Optional<User> user = userService.getUserByCin(cin);  // Use getUserByCin
        if (user.isPresent()) {
            return ResponseEntity.ok(user.get());  // Return the user if found
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);  // Return 404 if not found
        }
    }



    // Create a New User
    @PostMapping
    public ResponseEntity<User> createUser(@RequestBody User user) {
        User createdUser = userService.saveUser(user);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdUser);
    }

    // Update an Existing User
    @PutMapping("/{cin}")
    public ResponseEntity<User> updateUser(@PathVariable("cin") Long cin, @RequestBody User user) {
        user.setCin(cin); // Ensure the cin is correctly set
        User updatedUser = userService.saveUser(user);
        return ResponseEntity.ok(updatedUser);
    }

    // Delete a User
    @DeleteMapping("/{cin}")
    public ResponseEntity<Void> deleteUser(@PathVariable("cin") Long cin) {
        userService.deleteUser(cin);
        return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
    }
}
