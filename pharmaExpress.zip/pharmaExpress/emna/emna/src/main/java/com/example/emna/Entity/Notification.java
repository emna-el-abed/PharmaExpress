package com.example.emna.Entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
public class Notification {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    private Long userId;  // Foreign key to Users table

    @NotNull
    @Lob
    private String message;  // Message text

    @NotNull
    @Enumerated(EnumType.STRING)
    private NotificationType notificationType;  // Order or stock update

    public enum NotificationType {
        ORDER,
        STOCK_UPDATE
    }
}
