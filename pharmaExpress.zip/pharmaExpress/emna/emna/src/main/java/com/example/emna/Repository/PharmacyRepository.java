package com.example.emna.Repository;

import com.example.emna.Entity.Pharmacy;

import org.springframework.data.jpa.repository.JpaRepository;

public interface PharmacyRepository extends JpaRepository<Pharmacy, Long> {
    // Additional query methods can be added if needed
}
