package com.example.emna.Controller;

import com.example.emna.Entity.Medicament;
import com.example.emna.Service.MedicamentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/medicaments")
public class MedicamentController {

    @Autowired
    private MedicamentService medicamentService;

    // Create a new medicament
    @PostMapping
    public ResponseEntity<Medicament> createMedicament(@RequestBody Medicament medicament) {
        Medicament createdMedicament = medicamentService.createMedicament(medicament);
        return new ResponseEntity<>(createdMedicament, HttpStatus.CREATED);
    }

    // Get all medicaments
    @GetMapping
    public ResponseEntity<List<Medicament>> getAllMedicaments() {
        List<Medicament> medicaments = medicamentService.getAllMedicaments();
        return new ResponseEntity<>(medicaments, HttpStatus.OK);
    }

    // Get a medicament by ID
    @GetMapping("/{id}")
    public ResponseEntity<Medicament> getMedicamentById(@PathVariable Long id) {
        Optional<Medicament> medicament = medicamentService.getMedicamentById(id);
        return medicament.map(m -> new ResponseEntity<>(m, HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    // Update a medicament
    @PutMapping("/{id}")
    public ResponseEntity<Medicament> updateMedicament(@PathVariable Long id, @RequestBody Medicament medicament) {
        Medicament updatedMedicament = medicamentService.updateMedicament(id, medicament);
        return updatedMedicament != null ? new ResponseEntity<>(updatedMedicament, HttpStatus.OK)
                : new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    // Delete a medicament
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteMedicament(@PathVariable Long id) {
        medicamentService.deleteMedicament(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
